from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import * 
import json

# Creación de los widgets
app = QApplication([])
mwin = QWidget()
title_1 = QLabel("Notes' list")
title_2 = QLabel("Tags' list")
main_writable_box = QTextEdit()
tag_entrance = QLineEdit()
note_list = QListWidget()
tag_list = QListWidget()
create_note_button = QPushButton('Create note')
delete_note_button = QPushButton('Delete note')
save_note_button = QPushButton( 'Save note')
create_tag_button = QPushButton('Add to note')
delete_tag_button = QPushButton('Untag from note')
tag_search_button = QPushButton('Search notes by tag')

msg_note = QWidget()
msg_label = QLabel("Introduce the new note's title")
msg_box = QLineEdit()
confirm_button = QPushButton('Create note')
msg_line = QVBoxLayout()

search_tag_win = QWidget()
search_tag_result_win = QWidget()
tag_search_label = QLabel('Introduce the tag for the search:')
tag_search_results_label = QLabel('The following notes have the provided tag:')
tag_search_entrance = QLineEdit()
tag_search_button_interface = QPushButton('Search')
tag_search_confirm = QPushButton('Done')
tag_search_button_open = QPushButton('Open selected note')
tag_search_list = QListWidget()
tag_search_line_1 = QVBoxLayout()
tag_search_line_2 = QVBoxLayout()
tag_search_subline_2_2= QHBoxLayout()
tag_search_subline_2_1= QHBoxLayout()

msg_save = QWidget()
msg_save_label = QLabel('Changes made in the current note will be saved. Do you want to continue?')
msg_save_confirm = QPushButton('Yes')
msg_save_deny = QPushButton('No')
msg_save_line = QVBoxLayout()
msg_save_subline_1 = QHBoxLayout()
msg_save_subline_2 = QHBoxLayout()

msg_tag_save = QWidget()
msg_tag_save_label = QLabel('Changes made in the current note will be saved. Do you want to continue?')
msg_tag_save_confirm = QPushButton('Yes')
msg_tag_save_deny = QPushButton('No')
msg_tag_save_line = QVBoxLayout()
msg_tag_save_subline_1 = QHBoxLayout()
msg_tag_save_subline_2 = QHBoxLayout()


# Ajustado de los widgets
mwin.setWindowTitle('Smart Notes')
mwin.showMaximized()

msg_note.setWindowTitle("New note's creation")

search_tag_win.setWindowTitle('Search by tag')
search_tag_result_win.setWindowTitle('Search by tag results')

msg_save.setWindowTitle('Warning')

msg_tag_save.setWindowTitle('Warning')

note_list.setAlternatingRowColors(True)
tag_list.setAlternatingRowColors(True)
tag_search_list.setAlternatingRowColors(True)
# Colocación de los widgets principales en diseños
MainLine = QHBoxLayout()
TextLine = QHBoxLayout()
WidgetLine = QVBoxLayout()
NotesEditLine = QVBoxLayout()
NotesList = QVBoxLayout()
NotesButtons1 = QHBoxLayout()
NotesButtons2 = QHBoxLayout()
TagList = QVBoxLayout()
TagEditLine = QVBoxLayout()
TagButtons1 = QHBoxLayout()
TagButtons2 = QHBoxLayout()

TextLine.addWidget(main_writable_box)
NotesList.addWidget(title_1)
NotesList.addWidget(note_list)
NotesButtons1.addWidget(create_note_button)
NotesButtons1.addWidget(delete_note_button)
NotesButtons2.addWidget(save_note_button)
TagList.addWidget(title_2)
TagList.addWidget(tag_list)
TagList.addWidget(tag_entrance)
TagButtons1.addWidget(create_tag_button)
TagButtons1.addWidget(delete_tag_button)
TagButtons2.addWidget(tag_search_button)

NotesEditLine.addLayout(NotesList)
NotesEditLine.addLayout(NotesButtons1)
NotesEditLine.addLayout(NotesButtons2)
TagEditLine.addLayout(TagList)
TagEditLine.addLayout(TagButtons1)
TagEditLine.addLayout(TagButtons2)
WidgetLine.addLayout(NotesEditLine)
WidgetLine.addLayout(TagEditLine)
MainLine.addLayout(TextLine, stretch=2)
MainLine.addLayout(WidgetLine)
mwin.setLayout(MainLine)

msg_line.addWidget(msg_label)
msg_line.addWidget(msg_box)
msg_line.addWidget(confirm_button)
msg_note.setLayout(msg_line)

tag_search_line_1.addWidget(tag_search_label)
tag_search_line_1.addWidget(tag_search_entrance)
tag_search_line_1.addWidget(tag_search_button_interface)
tag_search_line_2.addWidget(tag_search_results_label)
tag_search_line_2.addWidget(tag_search_list)
tag_search_subline_2_2.addWidget(tag_search_confirm)
tag_search_subline_2_2.addWidget(tag_search_button_open)
tag_search_subline_2_1.addWidget(tag_search_results_label)
tag_search_subline_2_1.addWidget(tag_search_list)
tag_search_line_2.addLayout(tag_search_subline_2_1, stretch=4)
tag_search_line_2.addLayout(tag_search_subline_2_2)

search_tag_win.setLayout(tag_search_line_1)
search_tag_result_win.setLayout(tag_search_line_2)

msg_save_subline_1.addWidget(msg_save_label)
msg_save_subline_2.addWidget(msg_save_deny)
msg_save_subline_2.addWidget(msg_save_confirm)
msg_save_line.addLayout(msg_save_subline_1)
msg_save_line.addLayout(msg_save_subline_2)
msg_save.setLayout(msg_save_line)

msg_tag_save_subline_1.addWidget(msg_tag_save_label)
msg_tag_save_subline_2.addWidget(msg_tag_save_deny)
msg_tag_save_subline_2.addWidget(msg_tag_save_confirm)
msg_tag_save_line.addLayout(msg_tag_save_subline_1)
msg_tag_save_line.addLayout(msg_tag_save_subline_2)
msg_tag_save.setLayout(msg_tag_save_line)

# Estructuras de almacenado de elementos
class Global_var():
    def __init__(self, content):
        self.content = content
notes = dict()
with open('notes_data.json', 'r', encoding='utf-8') as file:
    notes = json.load(file)
current_note = Global_var(None)
tags_widgets = dict()
notes_widgets = dict()
for note in notes:
    notes_widgets[note] = QListWidgetItem(note)
    note_list.addItem(notes_widgets[note])

    

# Líneas funcionales iniciales del programa
for note in notes:
    tags_widgets[note] = list()
    for tag in notes[note]['tags']:
        tag = QListWidgetItem(tag)
        tags_widgets[note].append(tag)


# Creación de funciones

def save_text_changes(note):
    text = main_writable_box.toPlainText()
    notes[note]['content'] = text
    dump_to_json()

def add_note(note_name, note_content):
    notes[note_name] = {'name': note_name, 'content': note_content, 'tags': []}

def dump_to_json():
    with open('notes_data.json', 'w', encoding='utf-8') as file:
        json.dump(notes, file)

def create_note():
    msg = QMessageBox()
    note = msg_box.text()
    if msg_box.text() != '' and msg_box.text() not in notes:
        NoteName = msg_box.text()
        notes[NoteName] = {"name": NoteName, "tags": [], "content": ''}
        msg.setWindowTitle('Note created')
        msg.setText('The note was succesfully created.')
        notes_widgets[note] = QListWidgetItem(note)
        note_list.addItem(notes_widgets[note])
        tags_widgets[NoteName] = list()

    else:
        msg = QMessageBox()
        msg.setWindowTitle('Error')
        msg.setText('Make sure you have inserted a valid note name \n which is not already in use.')
    msg_box.setText('')
    msg.exec_()
    msg_note.hide()
    dump_to_json()

def add_tag(note_name, *args):
    tag_list_prob = args
    for tag in tag_list_prob:
        prob_var = tag
        if tag not in notes[note_name]['tags'] and tag !='':
            notes[note_name]['tags'].append(tag)
            tag = QListWidgetItem(tag)
            tag_list.addItem(tag)
            tag_entrance.setText('')
            tags_widgets[note_name].append(tag)
    dump_to_json()

def remove_tag(note_name, rem_tag): 
    clock = 0
    for i in notes[note_name]['tags']:
        if str(i) == str(rem_tag):
            del notes[note_name]['tags'][clock]
            ind = tags_widgets[note_name].index(tags_widgets[note_name][clock])
            sel_row = tag_list.row(tags_widgets[note_name][clock]) 
            tag_list.takeItem(sel_row)
            del tags_widgets[note_name][clock]
            tag_list.update()
        clock += 1
    tag_entrance.setText('')
    dump_to_json()
        
def set_main_text(note_name):
    text = notes[note_name]['content']
    main_writable_box.setText(text)

def clean_list(lista):
    for i in range(lista.count()):
        lista.takeItem(i)

def create_tag_function():
    add_tag(current_note.content, tag_entrance.text())

def delete_tag_function():
    remove_tag(current_note.content, tag_entrance.text())

def create_note_function():
    msg_note.resize(300, 75)
    msg_note.show()

def search_tag_start():
    text = tag_search_entrance.text()
    tag_search_entrance.setText('')
    sel_notes = list()
    for i in notes:
        if text in notes[i]['tags']:
            sel_notes.append(notes[i]['name'])
    for item in sel_notes:
        tag_search_list.addItem(QListWidgetItem(item))

def search_tag_function():
    search_tag_win.show()

def search_tag_step2_function():
    search_tag_win.hide()
    search_tag_win.update()
    search_tag_start()
    search_tag_result_win.show()

def search_tag_confirm_function():
    search_tag_result_win.hide()
    tag_search_list.clear()

def search_tag_open_function():
    print(tag_search_list.currentItem())

def change_note_function(current_note):
    if current_note.content != None:
        text = main_writable_box.toPlainText()
        notes[current_note.content]['content'] = text
        for i in range(len(notes[current_note.content]['tags']) + 1 ):
            tag_list.takeItem(i)
    new_note = note_list.currentItem().text()
    current_note.content = new_note
    set_main_text(current_note.content)
    set_main_text(current_note.content)
    for tag in tags_widgets[current_note.content]:
        tag_list.addItem(tag)
    msg_save.hide()
    dump_to_json()

def change_tag_list_note_function(current_note):
    if current_note.content != None:
        text = main_writable_box.toPlainText()
        notes[current_note.content]['content'] = text
        clean_list(tag_list)
    new_note = tag_search_list.currentItem().text()
    current_note.content = new_note
    set_main_text(current_note.content)
    clean_list(tag_list)
    for tag in tags_widgets[current_note.content]:
        tag_list.addItem(tag)
    msg_tag_save.hide()
    search_tag_win.hide()
    search_tag_result_win.hide()
    clean_list(tag_search_list)
    dump_to_json()

def change_tag_list_note_prefunction():
    change_tag_list_note_function(current_note)

def change_note_prefunction():
    change_note_function(current_note)

def save_caution():
    msg_save.show()
    msg_save_confirm.clicked.connect(change_note_prefunction)

def save_tag_caution():
    msg_tag_save.show()
    msg_tag_save_confirm.clicked.connect(change_tag_list_note_prefunction)

def save_function():
    save_text_changes(current_note.content)
    msg = QMessageBox()
    msg.setWindowTitle('Note Saved')
    msg.setText('The note was succesfully saved.')
    msg.show()
    msg.exec_()


# Conexiones internas

create_tag_button.clicked.connect(create_tag_function)
delete_tag_button.clicked.connect(delete_tag_function)
create_note_button.clicked.connect(create_note_function)
tag_search_button.clicked.connect(search_tag_function)
note_list.clicked.connect(save_caution)
save_note_button.clicked.connect(save_function)

confirm_button.clicked.connect(create_note)

tag_search_button_interface.clicked.connect(search_tag_step2_function)
tag_search_confirm.clicked.connect(search_tag_confirm_function)
tag_search_button_open.clicked.connect(save_tag_caution)

mwin.show()
app.exec_()
