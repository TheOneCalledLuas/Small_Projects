from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import * 
import json
App = QApplication([])
mwin = QWidget()
list = QListWidget()
item1 = QListWidgetItem('one')
item2 = QListWidgetItem('two')
item3 = QListWidgetItem('three')
list.addItem(item1)
list.addItem(item2)
list.addItem(item3)
print(item3.text())
line = QHBoxLayout()
line.addWidget(list)
mwin.setLayout(line)

def function_1():
    print('hi')

list.clicked.connect(function_1)

mwin.show()
App.exec_()