a = [0, 1, 2, 3]
print(a[2])
n = 4
try:

    print(a[n])
except IndexError:
    print(a[n-1])