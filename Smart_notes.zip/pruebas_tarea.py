import json
with open('notes_info.json', 'r', encoding='utf-8') as file:
    data =json.load(file)
    print(data)
    if data['Instrucciones de uso']['tags'] == list():
        print(1)