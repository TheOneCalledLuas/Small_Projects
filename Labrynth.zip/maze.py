from time import sleep
from pygame import *
import os
'''
IMPORTANTE
EL JUEGO HA SIDO PROGRAMADO PARA QUE SE EJECUTE EN
PANTALLA COMPLETA. PARA SALIR DE LA MISMA, PRESIONE
LA TECLA 'esc'. PARA PARAR LA MÚSICA PRESIONA 'm',
Y PARA CONTINUARLA PRESIONA 'c'. EL JUGADOR DE MUEVE
CON LAS TECLAS 'wasd'.
'''
#Creo una ventana para el juego con fondo.
init()
mixer.init()
mwin = display.set_mode((700, 500))
display.set_caption('Ventana')
background = transform.scale(image.load('background.jpg'), (700,500))
# Clase reproductora de música.
class Music_manager():
    def __init__(self):
        self.soundtrack = None
        self.sound = None
    
    def play_soundtrack(self, music=None):
        if music != None:
            self.soundtrack = music
        mixer.music.load(music)
        mixer.music.play()
    
    def stop_soundtrack(self):
        mixer.music.pause()
    
    def continue_soundtrack(self):
        mixer.music.unpause()
    
    def play_sound(self, sound=None):
        if sound != None:
            self.sound = sound
        one_sound = mixer.Sound(sound)
        one_sound.play()
    
mp3 = Music_manager()
mp3.play_soundtrack('jungles.ogg')



display.toggle_fullscreen()
#Creo una clase de objeto general
class entity():
    def __init__(self, xpos, ypos, width, lenght, image =None):
        self.xpos = xpos
        self.ypos = ypos
        self.width = width
        self.lenght = lenght
        self.object = None
        self.collide_area = draw.rect(mwin, (0, 150, 0), Rect(self.xpos, self.ypos, self.width, self.lenght))
        self.image = image

    #Método que crea el objeto con su imágen.
    def initialise(self):
        if self.image != None:
            self.object = transform.scale(image.load(self.image), (self.width, self.lenght))
        else:
            raise SyntaxWarning('Se intentó crear un objeto sin imágen.')
    # Método que crea la caja de colisión.
    def create_collide_area(self):
        self.collide_area = draw.rect(mwin, (0, 150, 0), Rect(self.xpos, self.ypos, self.width, self.lenght))
    # Método que muestra el objeto en pantalla.
    def show(self):
        if self.object != None:
            mwin.blit(self.object, (self.xpos, self.ypos))   
        else:
            raise SyntaxWarning('Se intentó mostrar un objeto sin inicializarlo antes.')

# Clase que puede moverse y hereda de la entidad común.
class cinetic_entity(entity):
    def __init__(self, xpos, ypos, width, lenght, speed, image=None):
        self.speed = speed
        super().__init__(xpos, ypos, width, lenght, image)
    
    # Métodos que mueven al personaje de forma intuitiva.
    def horizontal_step(self):
        self.xpos += self.speed
    def vertical_step(self):
        self.ypos += self.speed
    def left_step(self):
        self.xpos -= self.speed
    def right_step(self):
        self.xpos += self.speed
    def up_step(self):
        self.ypos -= self.speed
    def down_step(self):
        self.ypos += self.speed

#Creo dos objetos de la clase con movimiento
hero = cinetic_entity(20, 20, 50, 40, 5, image='hero.png')
hero.initialise()
hero.show()

cyborg = cinetic_entity(500, 300, 48, 40, 1, image='cyborg.png')
cyborg.initialise()
cyborg.show()

treasure = entity(575, 150, 50, 45, image='treasure.png') #xpos, ypos, width, lenght, image =None
treasure.initialise()
treasure.show()

walls = list()
wall1 = entity(150, 0, 25, 400)
walls.append(wall1)
wall2 = entity(300, 100, 25, 400)
walls.append(wall2)
wall3 = entity(450, 0, 25, 400)
walls.append(wall3)

title = font.Font(None, 50)

#manejo de evento “clic en “Cerrar ventana”
os.system('cls')
timer = time.Clock()
condition = True
last_move_contrary = None
goal1 = True

while condition:
    collide_condition = False
    cyborg.create_collide_area()
    hero.create_collide_area()
    treasure.create_collide_area()
    mwin.blit(background,(0, 0))
    cyborg.show()
    hero.show()
    treasure.show()
    wall1.create_collide_area()
    wall2.create_collide_area()
    wall3.create_collide_area()
    
    #b = draw.rect(mwin, (255, 0, 0), Rect(28, 22, 55, 45)) #55, 45
    
    timer.tick(60)
    display.update()

    keys_pressed = key.get_pressed()

    for wall in walls:
        if hero.collide_area.colliderect(wall.collide_area):
            exec(last_move_contrary)

    if keys_pressed[K_w] and hero.ypos > 0:
        hero.up_step()
        last_move_contrary = 'hero.down_step()'

    if keys_pressed[K_s] and hero.ypos < 460:
        hero.down_step()
        last_move_contrary = 'hero.up_step()'

    if keys_pressed[K_a] and hero.xpos > -5:
        hero.left_step()
        last_move_contrary = 'hero.right_step()'

    if keys_pressed[K_d] and hero.xpos < 650:
        hero.right_step()
        last_move_contrary = 'hero.left_step()'

    if keys_pressed[K_m]:
        mp3.stop_soundtrack()
    if keys_pressed[K_c]:
        mp3.continue_soundtrack()
    if keys_pressed[K_ESCAPE]:
        condition = False
    
    if cyborg.speed > 0:
        if cyborg.xpos > 650:
            cyborg.speed *= -1
    else:
        if cyborg.xpos < 500:
            cyborg.speed *= -1
    cyborg.horizontal_step()

    for e in event.get():
        if e.type == QUIT:
            condition = False
    
    if hero.collide_area.colliderect(treasure.collide_area):
        mp3.play_sound('kick.ogg')
        if goal1:
            treasure.xpos, treasure.ypos = 25, 25
            goal1 = False
        else:
            text = title.render('You win', True, (255,0,0))
            mwin.blit(text, (250, 250))
            display.update()
            condition = False
            sleep(3)

    elif hero.collide_area.colliderect(cyborg.collide_area):
        mp3.play_sound('kick.ogg')
        text = title.render('Game over', True, (255,0,0))
        mwin.blit(text, (250, 250))
        display.update()
        condition = False
        sleep(3)